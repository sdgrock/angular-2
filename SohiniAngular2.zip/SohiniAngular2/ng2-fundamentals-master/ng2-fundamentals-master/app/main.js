"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var eventsapp_module_1 = require('./eventsapp.module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(eventsapp_module_1.EventsAppModule);
//# sourceMappingURL=main.js.map