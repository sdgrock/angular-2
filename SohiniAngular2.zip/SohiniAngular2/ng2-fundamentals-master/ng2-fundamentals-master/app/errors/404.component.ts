import {Component} from '@angular/core'

@Component({
    template:
    `
    
        <h1>Error 404 Page Not Found</h1>

    `,
    styles:[`
        h1{color:red}
    `]
})

export class Error404Component{

}