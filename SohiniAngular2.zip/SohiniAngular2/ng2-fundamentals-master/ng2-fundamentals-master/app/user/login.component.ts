import {Component} from '@angular/core'
import {AuthService} from '../shared/auth.service'
import {Router} from '@angular/router'

@Component({
    templateUrl:'app/user/login.html',
    styles:[
        `
            em{color:red}
        `
    ]
})
export class LoginComponent{

    constructor(private authService:AuthService,private router:Router){

    }
    login(formValues){
        this.authService.authenticateUser(formValues.userName, formValues.password)
        this.router.navigate(['/events'])
    }
}