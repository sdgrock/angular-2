"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var EventThumbnailComponent = (function () {
    function EventThumbnailComponent() {
        this.eventclick = new core_1.EventEmitter();
    }
    EventThumbnailComponent.prototype.getstarttimeclass = function () {
        if (this.event.time === '10:00 am') {
            return ['changefont'];
        }
        else {
            return ['changecolor'];
        }
    };
    EventThumbnailComponent.prototype.getstarttimestyle = function () {
        if (this.event.time === '8:00 am') {
            return {
                'font-weight': 'bold', color: 'green'
            };
        }
        else {
            return {};
        }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], EventThumbnailComponent.prototype, "event", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], EventThumbnailComponent.prototype, "eventclick", void 0);
    EventThumbnailComponent = __decorate([
        core_1.Component({
            selector: 'event-thumbnail',
            template: "\n    <div [routerLink]=\"['/events',event.id]\" class=\"well hoverwell thumbnail\">\n                    <h2>{{event?.name|uppercase}}</h2>\n                    <div>Date:{{event?.date|date:'shortDate'}}</div>\n                    <div>Time:{{event?.time}}\n\n                        <div [ngStyle]=\"getstarttimestyle()\" [ngSwitch]=\"event?.time\">\n                            <div *ngSwitchCase=\"'8:00 am'\">[Early Start]</div>\n                            <div *ngSwitchCase=\"'9:00 am'\">[Regular Start]</div>\n                            <div *ngSwitchDefault>[Late Start]</div>\n                    \n                        </div>\n                    </div>\n\n                    <div>Price:{{event?.price|currency:'USD':true}}</div>\n                    <div *ngIf=\"event?.location\">\n                        <span>Location:{{event?.location?.address}}</span>\n                        <span>{{event?.location?.city}},{{event?.location?.country}}</span>\n                    </div>\n                    <div *ngIf=\"event?.onlineurl\">\n                        onlineurl:{{event?.onlineurl}}\n                    </div>\n    </div>\n\n                \n    ",
            styles: [
                "\n            .changefont{font-style:italic;color:blue}\n            .changecolor{color:green}\n            .thumbnail{min-height:210px}\n            h2{color:red}\n        "
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], EventThumbnailComponent);
    return EventThumbnailComponent;
}());
exports.EventThumbnailComponent = EventThumbnailComponent;
//# sourceMappingURL=eventthumbnail.component.js.map