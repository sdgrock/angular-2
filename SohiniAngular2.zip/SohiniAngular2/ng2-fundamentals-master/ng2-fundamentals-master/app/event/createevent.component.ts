import {Component} from '@angular/core'
import {Router} from '@angular/router'
@Component({
    template:
    `
    
        <h1>New Event</h1>
        <hr/>
        <div>
            <h3>[New Event Form goes here]</h3><br/><br/>
            <button type="submit">Save</button>
            <button type="button" (click)="cancelme()">Cancel</button>
        </div>
    `
})

export class CreateEventComponent{

    constructor(private router:Router){


    }
    cancelme(){
        this.router.navigate(['/events'])
    }

}