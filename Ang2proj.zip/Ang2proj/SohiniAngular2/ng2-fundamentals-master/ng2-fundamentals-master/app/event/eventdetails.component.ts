import {Component} from '@angular/core'
import {EventService} from '../shared/event.service'
import {ActivatedRoute} from '@angular/router'

@Component({
    templateUrl:'app/event/event-details.component.html',
    styles:[
        `
        .event-image{height:100px}
        `
    ]
})

export class EventDetailsComponent{
    event:any

    constructor(private eventService:EventService,
                private actroute:ActivatedRoute){
        
            this.event=eventService.getEvent(+this.actroute.snapshot.params['id'])
    }
}