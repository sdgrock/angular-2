import {Component} from '@angular/core'
import {EventService,IEvent} from '../shared/index'

@Component({
    selector:'event-list',
    /*templateUrl:'app/event/eventlist.html'*/
    template:
    `
            <div>
                
                <h1>Upcoming Angular Events</h1>
                <hr/>

                <div *ngFor="let event of events" class="col-md-5">

                <event-thumbnail [event]="event"></event-thumbnail>
                </div>

            </div>

            

            
    `
})
export class EventListComponent{
    events:IEvent[]

    constructor(private eventService:EventService){
            this.events=eventService.getEvents()

    }
    
   

   accessdata(data){
       console.log("data received from inner comp is "+data)
   }
}